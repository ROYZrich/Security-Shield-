SECURITY SHIELD — PUBBLICAZIONE SU GITHUB PAGES

Questa cartella contiene un sito statico in italiano:
- index.html
- terms.html
- privacy.html

IMPORTANTE
La privacy policy è una bozza con campi da completare. Hai indicato che il bot salva dati, ma non hai specificato quali dati né i tempi di conservazione. Non pubblicare i documenti finché non hai sostituito tutti i campi [TRA PARENTESI QUADRE] con informazioni vere e verificato il testo.

COME PUBBLICARE (da browser, anche su telefono)
1. Accedi a https://github.com/
2. Crea un nuovo repository pubblico chiamato: security-shield-pages
3. Carica index.html, terms.html e privacy.html nella radice del repository.
4. Apri Settings > Pages.
5. In Build and deployment scegli "Deploy from a branch".
6. Seleziona branch "main" e cartella "/ (root)", poi Save.
7. Attendi che GitHub Pages pubblichi il sito.

Se il nome utente GitHub è TUO_USERNAME, gli URL attesi saranno:
https://TUO_USERNAME.github.io/security-shield-pages/terms.html
https://TUO_USERNAME.github.io/security-shield-pages/privacy.html

Questi URL sono SOLO MODELLI fino alla pubblicazione riuscita. Sostituisci TUO_USERNAME con il tuo username GitHub e verifica che le pagine si aprano prima di inserirle nel Discord Developer Portal.

Nel Developer Portal:
- URL dei Termini di Servizio: URL effettivo di terms.html
- URL dell'Informativa sulla privacy: URL effettivo di privacy.html
- URL del punto d'interazione e URL di verifica dei ruoli collegati: lasciali vuoti se non implementi quelle funzioni specifiche.
